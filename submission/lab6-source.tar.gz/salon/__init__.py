"""Beauty salon application."""
